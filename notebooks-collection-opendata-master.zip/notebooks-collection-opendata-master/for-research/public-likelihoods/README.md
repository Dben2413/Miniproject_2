ATLAS Public JSON Workspace Demonstration notebook using just ROOT nightly from condaforge

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/will-cern/statanalysis-binder-demo/demo2?labpath=index.ipynb)
